import "dotenv/config";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = Number(process.env.PORT || 3000);
const MODEL = process.env.OPENAI_MODEL || "gpt-6-astra";

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const chatLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 20,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many requests. Please wait a minute and try again." }
});

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.OPENAI_API_KEY), model: MODEL });
});

app.post("/api/chat", chatLimiter, async (req, res) => {
  if (!process.env.OPENAI_API_KEY) {
    return res.status(503).json({
      error: "AXION is not connected yet. Add your API key to the server .env file."
    });
  }

  const messages = req.body?.messages;
  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: "Please send a message." });
  }

  const safeMessages = messages.slice(-20).map((item) => {
    const role = item?.role === "assistant" ? "assistant" : "user";
    const content = typeof item?.content === "string" ? item.content.slice(0, 12000) : "";
    return { role, content };
  }).filter((item) => item.content.trim());

  if (!safeMessages.length || safeMessages[safeMessages.length - 1].role !== "user") {
    return res.status(400).json({ error: "The latest message must be from the user." });
  }

  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await client.responses.create({
      model: MODEL,
      instructions: "You are AXION, a helpful, clear, friendly AI assistant. Give accurate, age-appropriate answers. If you are unsure, say so. Do not claim to have performed actions you have not performed.",
      input: safeMessages
    });

    res.json({ reply: response.output_text || "I couldn't produce a text response. Please try again." });
  } catch (error) {
    console.error("AXION API error:", error?.message || error);
    const status = error?.status === 401 ? 401 : 502;
    res.status(status).json({
      error: status === 401
        ? "The API key was rejected. Check the key in your server .env file."
        : "AXION couldn't reach the AI service. Please try again shortly."
    });
  }
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`AXION is running at http://localhost:${PORT}`);
  if (!process.env.OPENAI_API_KEY) {
    console.log("Add OPENAI_API_KEY to .env to enable real AI replies.");
  }
});
