AXION AI 2.0 — SETUP GUIDE
==========================

WHAT IS INCLUDED
- public/index.html: AXION chat interface
- public/Brain.js: browser helper that sends chat history to your server
- server.js: secure server-side OpenAI API connection
- package.json: project dependencies and run commands
- .env.example: example environment settings

REQUIREMENTS
- A computer (Windows, macOS, or Linux)
- Node.js 20 or newer
- Internet connection
- An OpenAI API key and API billing/usage enabled

IMPORTANT ABOUT COST
ChatGPT subscriptions and API usage are separate. API calls may incur charges according to your API account and model usage. Check your API billing and usage limits before using it.

SETUP ON WINDOWS
1. Extract the AXION_AI_2.zip file.
2. Install Node.js 20 or newer from https://nodejs.org/
3. Open the extracted AXION_AI_2 folder.
4. Copy .env.example and rename the copy to .env
5. Open .env with Notepad. Replace put_your_api_key_here with your API key.
6. Save the file. Do not share it or paste the key into index.html or Brain.js.
7. In the folder address bar, type cmd and press Enter.
8. Run: npm install
9. Run: npm start
10. Open http://localhost:3000 in your browser.

TO STOP
Return to the terminal and press Ctrl+C.

IF AXION SAYS IT IS NOT CONNECTED
- Check that the .env file is in the same folder as server.js.
- Check that OPENAI_API_KEY is spelled correctly and the key is valid.
- Restart the server after changing .env.
- Check API account access, billing, and usage limits.

FEATURE NOTES
- Voice input depends on browser speech-recognition support and microphone permission.
- Voice replies use the browser's speech engine.
- Text file attachment supports .txt and .md files up to 100 KB.
- Chat history is stored in this browser on this device.
- This starter project does not include user accounts or cloud-synced memory.
- Do not expose the server publicly without adding authentication, HTTPS, stricter abuse protection, and deployment security.

OFFICIAL API GUIDE
https://developers.openai.com/api/docs/quickstart
